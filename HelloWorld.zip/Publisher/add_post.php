<?php
require_once '../secure_web.php';
require_once '../partition_user.php';
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="keywords" content="News">
    <meta name="description" content="HelloWorld news Website.">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="icon" type="image/png" sizes="32x32" href="../favicon-32x32.png">
    <link rel="manifest" href="../site.webmanifest">
    <script src="https://kit.fontawesome.com/c7e7696453.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="../css/main_forms.css" type="text/css">
    <title>ADD POST | HelloWolrd</title>
</head>
<body>
<div class="signup_login">
    <form  action="<?php $_SERVER['PHP_SELF']?>" method="post" enctype="multipart/form-data">
        <label for="Title" >Title <em>&#x2a;</em></label>
        <input id="Title" name="title" required="" type="text" />
        <label for="article">Enter full Article <em>&#x2a;</em></label>
        <textarea id="article" name="Article" required="" rows="8"></textarea>
        <label for="location" >Location <em>&#x2a;</em></label>
        <input id="location" name="location" required="" type="text">
        <!--<div class="custom-select">-->
            <select name="category">
                <option selected disabled>SELECT CATEGORY</option>
                <option value="Science&Technology">Science & Technology</option>
                <option value="Entertainment">Entertainment</option>
                <option value="Sports">Sports</option>
                <option value="Lifestyle">Lifestyle</option>
                <option value="Politics">Politics</option>
                <option value="Business">Business</option>
                <option value="Food">Food</option>
            </select>
        <!--</div>-->

        <br>
        <br>
        <label class="file" for="file" >Choose media</label>
        <input  type="file"  id="file" name="imgToUpload" required=""/>
        <div id="file-upload-filename"></div>
        <br>
        <br>
        <button id="submit" type="submit" name="post">POST</button>
        <br>
        <br>
    </form>
</div>
    <script src="../JS/file_choose_nm.js"></script>
</body>
</html>
<?php
require_once '../config.php';
    if(isset($_POST['post'])) {
        $date = date('d M,Y');
        $article = mysqli_real_escape_string($cn, $_POST['Article']);
        $location = mysqli_real_escape_string($cn, $_POST['location']);
        $title = mysqli_real_escape_string($cn, $_POST['title']);

        $status = 'error';
        if (!empty($_FILES["imgToUpload"]["name"])) {
            // Get file info
            $fileName = basename($_FILES["imgToUpload"]["name"]);
            $fileType = pathinfo($fileName, PATHINFO_EXTENSION);
            $size = $_FILES['imgToUpload']['size'];
            if ($size <= 1000000) {
                // Allow certain file formats
                $allowTypes = array('jpg', 'png', 'jpeg', 'gif', 'JPG', 'JPEG', 'PNG', 'GIF');
                if (in_array($fileType, $allowTypes)) {
                    $image = $_FILES['imgToUpload']['tmp_name'];
                    $imgContent = addslashes(file_get_contents($image));

                    // Insert image content into database
                    $post = mysqli_query($cn, "INSERT INTO article (title, category, post_date , description, id, location, media) VALUES ('{$title}','{$_POST['category']}','{$date}','{$article}',{$_SESSION['id']},'{$location}','{$imgContent}')");

                    if ($post) {
                        echo "<script>alert('Post uploaded successfully🎉.'); window.location = 'http://localhost/Helloworld/Publisher/add_post.php';</script>";
                    } else {
                        echo "<script>alert('Post not uploaded! Please try again.😟'); window.location = 'http://localhost/Helloworld/Publisher/add_post.php';</script>";
                    }
                }else{
                    echo "<script>alert('Sorry, only JPG, JPEG, PNG, & GIF files are allowed to upload.🤷‍♂️'); window.location = 'http://localhost/Helloworld/Publisher/add_post.php';</script>";
                }
            }else{
                echo "<script>alert('Sorry, only files with size 1MB or lesser are allowed to upload.😔'); window.location = 'http://localhost/Helloworld/Publisher/add_post.php';</script>";
            }
        }else{
            echo "<script>alert('Please select an image file to upload.🤷‍♀️'); window.location = 'http://localhost/Helloworld/Publisher/add_post.php';</script>";
        }
    }
?>
