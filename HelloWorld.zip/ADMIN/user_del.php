<?php
require_once 'secure_admin.php';
require_once '../config.php';
$get_img = mysqli_query($cn, "SELECT photo FROM user_details WHERE id = {$_GET['id']}");
if(mysqli_affected_rows($cn) > 0) {
    while ($img = mysqli_fetch_assoc($get_img)) {
        if($img['photo'] != "") {
            $folder = 'user_profile/';
            $del_img = $folder . $img['photo'];
            $f = unlink($del_img);
            $del_cmt = mysqli_query($cn, "DELETE FROM comment WHERE id = {$_GET['id']}");
            $del_post = mysqli_query($cn, "DELETE FROM article WHERE id = {$_GET['id']}");
            $del_pub = mysqli_query($cn, "DELETE FROM valid_pub WHERE id = {$_GET['id']}");
            $del_user = mysqli_query($cn,"DELETE FROM user_details WHERE id = {$_GET['id']}");
        }else{
            $del_cmt = mysqli_query($cn, "DELETE FROM comment WHERE id = {$_GET['id']}");
            $del_post = mysqli_query($cn, "DELETE FROM article WHERE id = {$_GET['id']}");
            $del_pub = mysqli_query($cn, "DELETE FROM valid_pub WHERE id = {$_GET['id']}");
            $del_user = mysqli_query($cn,"DELETE FROM user_details WHERE id = {$_GET['id']}");
        }
    }
}
echo "<script>window.location = 'http://localhost/Helloworld/ADMIN/home.php';</script>";


?>
