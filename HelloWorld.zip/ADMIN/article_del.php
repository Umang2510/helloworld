<?php
require_once 'secure_admin.php';
require_once '../config.php';
    mysqli_query($cn,"DELETE FROM comment WHERE a_id = {$_GET['a_id']}");
    mysqli_query($cn, "DELETE FROM article WHERE a_id = {$_GET['a_id']}");

echo "<script>window.location = 'http://localhost/Helloworld/ADMIN/home.php';</script>";
?>