<?php
require_once 'secure_admin.php';
require_once '../config.php';

$del_feedback = mysqli_query($cn,"DELETE FROM feedback WHERE id = {$_GET['id']}");

echo "<script>window.location = 'http://localhost/Helloworld/ADMIN/home.php';</script>";


?>
