<?php
    require_once '../config.php';
    session_start();
    if(!isset($_SESSION['id']) && !isset($_SESSION['password'])){
        echo "<script>window.location = 'http://localhost/Helloworld/index.php';</script>";
    }
    elseif(($_SESSION['role'] == 1) && ($_SESSION['role'] == 0) ){
        echo "<script>window.location = 'http://localhost/Helloworld/index.php';</script>";
    }
?>