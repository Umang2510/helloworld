<?php
require_once 'secure_admin.php';
require_once '../config.php';
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="keywords" content="News">
    <meta name="description" content="HelloWorld news Website.">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="icon" type="image/png" sizes="32x32" href="../favicon-32x32.png">
    <link rel="manifest" href="../site.webmanifest">
    <script src="https://kit.fontawesome.com/c7e7696453.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="admin.css" type="text/css">

    <title>ADMIN | HelloWolrd</title>
</head>
<body>
    <header>
        <nav>
            <center>
        <div class="logo"><a href="http://localhost/Helloworld/ADMIN/home.php"><img style="float: left;" src="../images/helloWorld_white.png" alt="HelloWorld" height="10%" width="10%"><div class="logo_text"> HelloWorld</div></a></div>
            </center>
        </nav>
        <nav class="update">
            <ul>
                <li><a href="updateinfo.php">Update Profile</a> </li>
            </ul>
        </nav>
    </header>
<div class="table">
   <h1>Report</h1>
    <table border="1">
        <tr>
            <th>ID</th>
            <th>User ID</th>
            <th>Article ID</th>
            <th>Delete</th>
        </tr>
        <?php
            $getreport = mysqli_query($cn,"SELECT * FROM report");
            if(mysqli_affected_rows($cn)>0){
                while ($report = mysqli_fetch_assoc($getreport)){
                    echo "<tr>";
                    echo "<td>";
                    echo $report['id'];
                    echo "</td>";
                    echo "<td>";
                    echo $report['u_id'];
                    echo "</td>";
                    echo "<td>";
                    echo $report['a_id'];
                    echo "</td>";
                    echo "<td>"."<a href='report_del.php?id=".$report['id']."'>"."<i class='fas fa-trash'></i>"."</a>";
                    echo "</tr>";
                }
            }else{
                echo "NO DATA.";
            }
        ?>
    </table>
    <br>
    <h1>Users</h1>
    <table border="1">
        <tr>
            <th>User ID</th>
            <th>Contact</th>
            <th>Email</th>
            <th>Password</th>
            <th>User name</th>
            <th>Photo</th>
            <th>Role</th>
            <th>Delete</th>
        </tr>
        <?php $getuser = mysqli_query($cn, "SELECT * FROM user_details");
                if(mysqli_affected_rows($cn)>0){
                    while($user = mysqli_fetch_assoc($getuser)){
                        echo "<tr>";
                        echo "<td>".$user['id']."</td>";
                        echo "<td>".$user['contact']."</td>";
                        echo "<td>".$user['email']."</td>";
                        echo "<td>".$user['password']."</td>";
                        echo "<td>".$user['usernm']."</td>";
                        echo "<td>".$user['photo']."</td>";
                        echo "<td>".$user['role']."</td>";
                        echo "<td>"."<a href='user_del.php?id=".$user['id']."'>"."<i class='fas fa-trash'></i>"."</a>";
                        echo "</tr>";
                    }

                }else{
                    echo "NO DATA";
                }
                ?>
    </table><br>
    <h1>Articles</h1>
    <table border="1">
        <tr>
            <th>Article ID</th>
            <th>Title</th>
            <th>Category</th>
            <th>Post date</th>
            <th>Description</th>
            <th>User ID</th>
            <th>Location</th>
            <th>Media</th>
            <th>Delete</th>
        </tr>
        <?php
            $getarticle = mysqli_query($cn, "SELECT * FROM article");
            if(mysqli_affected_rows($cn)>0){
                while($article = mysqli_fetch_assoc($getarticle)){
                    echo "<tr>";
                    echo "<td>".$article['a_id']."</td>";
                    echo "<td>".$article['title']."</td>";
                    echo "<td>".$article['category']."</td>";
                    echo "<td>".$article['post_date']."</td>";
                    echo "<td>".$article['description']."</td>";
                    echo "<td>".$article['id']."</td>";
                    echo "<td>".$article['location']."</td>";
                    echo "<td class='img'>";
                    ?>
                    <img src="data:image/jpg;charset=utf8;base64,<?php echo base64_encode($article['media']); ?>" />
                    <?php echo "</td>";
                    echo "<td>"."<a href='article_del.php?a_id=".$article['a_id']."'>"."<i class='fas fa-trash'></i>"."</a>";
                    echo "</tr>";
                }
            }else{
                echo "NO DATA";
            }
        ?>
    </table><br>
    <h1>Publishers</h1>
    <table border="1">
        <tr>
            <th>User ID</th>
            <th>Contact</th>
            <th>Email</th>
            <th>Password</th>
            <th>User name</th>
            <th>Photo</th>
            <th>Role</th>
            <th>Delete</th>
        </tr>
        <?php $getpub = mysqli_query($cn, "SELECT * FROM user_details WHERE role = 1");
        if(mysqli_affected_rows($cn)>0){
            while($pub = mysqli_fetch_assoc($getpub)){
                echo "<tr>";
                echo "<td>".$pub['id']."</td>";
                echo "<td>".$pub['contact']."</td>";
                echo "<td>".$pub['email']."</td>";
                echo "<td>".$pub['password']."</td>";
                echo "<td>".$pub['usernm']."</td>";
                echo "<td>".$pub['photo']."</td>";
                echo "<td>".$pub['role']."</td>";
                echo "<td>"."<a href='user_del.php?id=".$pub['id']."'>"."<i class='fas fa-trash'></i>"."</a>";

                echo "</tr>";
            }

        }else{
            echo "NO DATA";
        }
        ?>
    </table>
    <br>
    <h1>Feedback</h1>
    <table border="1">
        <tr>
            <th>User ID</th>
            <th>Name</th>
            <th>Text</th>
            <th>Delete</th>
        </tr>
        <?php $get = mysqli_query($cn, "SELECT * FROM Feedback");
        if(mysqli_affected_rows($cn)>0){
            while($feedback = mysqli_fetch_assoc($get)){
                echo "<tr>";
                echo "<td>".$feedback['id']."</td>";
                echo "<td>".$feedback['name']."</td>";
                echo "<td>".$feedback['text']."</td>";
                echo "<td>"."<a href='feedback_del.php?id=".$feedback['id']."'>"."<i class='fas fa-trash'></i>"."</a>";

                echo "</tr>";
            }

        }else{
            echo "NO DATA";
        }
        ?>
    </table>
</div>
</body>
</html>