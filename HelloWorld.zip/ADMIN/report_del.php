<?php
require_once 'secure_admin.php';
require_once '../config.php';
 mysqli_query($cn, "DELETE FROM report WHERE id = {$_GET['id']}");
 echo "<script>window.location = 'http://localhost/Helloworld/ADMIN/home.php';</script>";
?>
